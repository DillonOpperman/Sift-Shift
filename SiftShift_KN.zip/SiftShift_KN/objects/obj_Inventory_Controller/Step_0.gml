// Toggle inventory with Tab or I key
if (keyboard_check_pressed(vk_tab) || keyboard_check_pressed(ord("I"))) {
    inventory_open = !inventory_open;
    player_panel.visible = inventory_open;

    // If closing, return any held item
    if (!inventory_open && inv_input_is_holding(inv_input)) {
        _inv_input_return_held(inv_input);
    }

    // Close any external panel too
    if (!inventory_open && external_panel != undefined) {
        inv_close_external(self);
    }
}

// Escape closes inventory
if (keyboard_check_pressed(vk_escape) && inventory_open) {
    inventory_open = false;
    player_panel.visible = false;

    if (inv_input_is_holding(inv_input)) {
        _inv_input_return_held(inv_input);
    }
    if (external_panel != undefined) {
        inv_close_external(self);
    }
}

// Process input when inventory is open
if (inventory_open) {
    inv_input_update(inv_input);
}