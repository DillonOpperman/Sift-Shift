// Initialize the item database (must be first)
item_db_init();

// Create the player inventory (10 columns x 4 rows = 40 slots)
// Matches the reference layout with numbered slots 1-10
player_inv = inventory_create(10, 4, "player");

// Create UI config — warm parchment / medieval style
ui_config = inv_ui_config_create();
// If you have custom fonts from the Ben branch, assign them here:
// ui_config.font_normal = fnt_UI;
// ui_config.font_small  = fnt_HUD;

// Create UI panel for the player inventory
// Centered horizontally in the GUI viewport
var _gui_w = display_get_gui_width();
var _gui_h = display_get_gui_height();
var _cell  = ui_config.slot_size + ui_config.slot_padding;
var _bdr   = ui_config.border_width * 2;
var _panel_w = (_cell * 10) - ui_config.slot_padding + (ui_config.panel_padding * 2) + _bdr;
var _panel_h = (_cell * 4) - ui_config.slot_padding + (ui_config.panel_padding * 2) + _bdr + ui_config.tab_height;

player_panel = inv_ui_panel_create(
    player_inv,
    floor((_gui_w - _panel_w) / 2),   // centered X
    floor((_gui_h - _panel_h) / 2),   // centered Y on screen
    "Inventory",
    ui_config
);
player_panel.visible = false;  // starts closed

// Create the input handler
inv_input = inv_input_create();
inv_input_add_panel(inv_input, player_panel);

// Inventory open/close state
inventory_open = false;

// External panel (for chests, machines, etc.)
external_panel = undefined;

// === DEBUG: Add some starter items ===
inventory_add_item(player_inv, "copper_ore", 15);