if (!inventory_open) exit;

var _mx = device_mouse_x_to_gui(0);
var _my = device_mouse_y_to_gui(0);

// Draw a semi-transparent overlay behind the inventory
draw_set_alpha(0.3);
draw_set_color(c_black);
draw_rectangle(0, 0, display_get_gui_width(), display_get_gui_height(), false);
draw_set_alpha(1);
draw_set_color(c_white);

// Draw the player inventory panel
var _held = inv_input_is_holding(inv_input) ? inv_input.held : undefined;
inv_ui_draw(player_panel, _mx, _my, _held);

// Draw external panel (chest, machine) if open
if (external_panel != undefined) {
    inv_ui_draw(external_panel, _mx, _my, _held);
}

// Draw tooltips (on top of everything)
// Only show tooltip if NOT holding an item (cleaner UX)
if (!inv_input_is_holding(inv_input)) {
    inv_ui_draw_tooltip(player_panel, _mx, _my);
    if (external_panel != undefined) {
        inv_ui_draw_tooltip(external_panel, _mx, _my);
    }
}

// Draw the held/dragged item on the cursor (always on top)
if (inv_input_is_holding(inv_input)) {
    inv_ui_draw_held_item(inv_input.held, _mx, _my, ui_config);
}

/// Opens an external inventory panel (chest, machine, etc.)
/// @param {id}     _controller  The controller instance (self)
/// @param {struct} _inv         The external inventory struct
/// @param {string} _title       Panel title
function inv_open_external(_controller, _inv, _title) {
    var _cfg = _controller.ui_config;
    var _gui_w = display_get_gui_width();

    // Position: left side of screen
    var _panel_w = (_cfg.slot_size + _cfg.slot_padding) * _inv.cols
                   - _cfg.slot_padding + _cfg.panel_padding * 2;

    _controller.external_panel = inv_ui_panel_create(
        _inv,
        floor((_gui_w - _panel_w) / 2),
        40,
        _title,
        _cfg
    );
    _controller.external_panel.visible = true;

    // Register with input handler
    inv_input_add_panel(_controller.inv_input, _controller.external_panel);

    // Open the player inventory too
    _controller.inventory_open = true;
    _controller.player_panel.visible = true;
}

/// Closes the external panel.
/// @param {id} _controller
function inv_close_external(_controller) {
    if (_controller.external_panel != undefined) {
        inv_input_remove_panel(_controller.inv_input, _controller.external_panel);
        _controller.external_panel = undefined;
    }
}
