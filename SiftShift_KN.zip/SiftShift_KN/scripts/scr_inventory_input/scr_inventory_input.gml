/// Creates the global input state. Call once at init.
/// @returns {struct}
function inv_input_create() {
    return {
        // The item currently on the cursor (slot struct)
        held: slot_create_empty(),

        // Source tracking (for animation / cancel)
        held_source_inv:   undefined,
        held_source_index: -1,

        // Drag state
        is_dragging:    false,
        drag_start_x:   0,
        drag_start_y:   0,
        drag_threshold: 4,  // pixels before drag activates

        // Multi-panel support: array of all active ui panels
        panels: [],

        // Feedback state
        last_action:      "",    // "pickup", "place", "merge", "swap", "split", "drop"
        action_timer:     0,
        invalid_slot:     -1,
        invalid_timer:    0
    };
}

/// Registers a panel with the input handler.
/// @param {struct} _input
/// @param {struct} _panel
function inv_input_add_panel(_input, _panel) {
    array_push(_input.panels, _panel);
}

/// Removes a panel from the input handler.
/// @param {struct} _input
/// @param {struct} _panel
function inv_input_remove_panel(_input, _panel) {
    for (var i = array_length(_input.panels) - 1; i >= 0; i--) {
        if (_input.panels[i] == _panel) {
            array_delete(_input.panels, i, 1);
        }
    }
}

/// Clears all panels (e.g., when closing all inventories).
/// @param {struct} _input
function inv_input_clear_panels(_input) {
    _input.panels = [];
}

// ─────────────────────────────────────────────────────────────
// MAIN UPDATE — call from Step event
// ─────────────────────────────────────────────────────────────

/// Processes all mouse input for the inventory system.
/// Call once per frame in the Step event.
///
/// @param {struct} _input   The input state struct
function inv_input_update(_input) {
    var _mx = device_mouse_x_to_gui(0);
    var _my = device_mouse_y_to_gui(0);

    // Tick timers
    if (_input.action_timer > 0) _input.action_timer--;
    if (_input.invalid_timer > 0) _input.invalid_timer--;

    // Find which panel and slot the mouse is over
    var _hover_panel = undefined;
    var _hover_slot  = -1;

    for (var i = 0; i < array_length(_input.panels); i++) {
        var _p = _input.panels[i];
        if (!_p.visible) continue;
        var _s = inv_ui_get_slot_at(_p, _mx, _my);
        if (_s >= 0) {
            _hover_panel = _p;
            _hover_slot  = _s;
            break;
        }
    }

    // ── LEFT CLICK ─────────────────────────────────────────
    if (mouse_check_button_pressed(mb_left)) {
        _inv_input_handle_left_click(_input, _hover_panel, _hover_slot);
    }

    // ── RIGHT CLICK ────────────────────────────────────────
    if (mouse_check_button_pressed(mb_right)) {
        _inv_input_handle_right_click(_input, _hover_panel, _hover_slot);
    }

    // ── DRAG TRACKING ──────────────────────────────────────
    if (mouse_check_button(mb_left) && !slot_is_empty(_input.held)) {
        _input.is_dragging = true;
    }
    if (mouse_check_button_released(mb_left)) {
        _input.is_dragging = false;
    }
}

// ─────────────────────────────────────────────────────────────
// LEFT CLICK HANDLER
// ─────────────────────────────────────────────────────────────

function _inv_input_handle_left_click(_input, _hover_panel, _hover_slot) {
    var _holding = !slot_is_empty(_input.held);

    // Click outside all panels while holding → drop / cancel
    if (_hover_panel == undefined || _hover_slot < 0) {
        if (_holding) {
            // Check if we clicked on any panel at all (but not a slot)
            var _mx = device_mouse_x_to_gui(0);
            var _my = device_mouse_y_to_gui(0);
            var _on_panel = false;
            for (var i = 0; i < array_length(_input.panels); i++) {
                if (inv_ui_point_in_panel(_input.panels[i], _mx, _my)) {
                    _on_panel = true;
                    break;
                }
            }
            if (!_on_panel) {
                // Drop item (return to source or discard)
                _inv_input_return_held(_input);
                _input.last_action = "drop";
                _input.action_timer = 15;
            }
        }
        return;
    }

    var _inv  = _hover_panel.inv;
    var _slot = _inv.slots[_hover_slot];

    if (!_holding) {
        // ── PICK UP ────────────────────────────────────────
        if (!slot_is_empty(_slot)) {
            _input.held.item_id = _slot.item_id;
            _input.held.qty     = _slot.qty;
            _input.held_source_inv   = _inv;
            _input.held_source_index = _hover_slot;

            inventory_clear_slot(_inv, _hover_slot);

            _input.last_action  = "pickup";
            _input.action_timer = 10;
        }
    } else {
        // ── PLACE / MERGE / SWAP ───────────────────────────
        if (slot_is_empty(_slot)) {
            // Place into empty slot
            inventory_set_slot(_inv, _hover_slot, _input.held.item_id, _input.held.qty);
            _input.held = slot_create_empty();
            _input.last_action  = "place";
            _input.action_timer = 10;
        } else if (_slot.item_id == _input.held.item_id) {
            // Same item: merge stack
            var _max   = item_db_max_stack(_slot.item_id);
            var _space = _max - _slot.qty;
            var _move  = min(_space, _input.held.qty);

            if (_move > 0) {
                _slot.qty += _move;
                _input.held.qty -= _move;
                if (_input.held.qty <= 0) {
                    _input.held = slot_create_empty();
                }
                _inventory_notify(_inv, _hover_slot);
                _input.last_action  = "merge";
                _input.action_timer = 10;
            } else {
                // Destination full — swap
                _inv_input_swap_with_held(_input, _inv, _hover_slot);
            }
        } else {
            // Different item: swap
            _inv_input_swap_with_held(_input, _inv, _hover_slot);
        }
    }
}

// ─────────────────────────────────────────────────────────────
// RIGHT CLICK HANDLER
// ─────────────────────────────────────────────────────────────

function _inv_input_handle_right_click(_input, _hover_panel, _hover_slot) {
    if (_hover_panel == undefined || _hover_slot < 0) return;

    var _inv  = _hover_panel.inv;
    var _slot = _inv.slots[_hover_slot];
    var _holding = !slot_is_empty(_input.held);

    if (_holding) {
        // ── PLACE ONE ──────────────────────────────────────
        // Right-click while holding: place a single item
        if (slot_is_empty(_slot)) {
            inventory_set_slot(_inv, _hover_slot, _input.held.item_id, 1);
            _input.held.qty -= 1;
            if (_input.held.qty <= 0) {
                _input.held = slot_create_empty();
            }
            _input.last_action  = "place";
            _input.action_timer = 10;
        } else if (_slot.item_id == _input.held.item_id) {
            var _max = item_db_max_stack(_slot.item_id);
            if (_slot.qty < _max) {
                _slot.qty += 1;
                _input.held.qty -= 1;
                if (_input.held.qty <= 0) {
                    _input.held = slot_create_empty();
                }
                _inventory_notify(_inv, _hover_slot);
                _input.last_action  = "place";
                _input.action_timer = 10;
            }
        }
    } else {
        // ── SPLIT STACK ────────────────────────────────────
        // Right-click on a slot: take half the stack
        if (!slot_is_empty(_slot) && _slot.qty > 1) {
            var _split = inventory_split_stack(_inv, _hover_slot);
            _input.held = _split;
            _input.held_source_inv   = _inv;
            _input.held_source_index = _hover_slot;
            _input.last_action  = "split";
            _input.action_timer = 10;
        } else if (!slot_is_empty(_slot) && _slot.qty == 1) {
            // Pick up the single item
            _input.held.item_id = _slot.item_id;
            _input.held.qty     = 1;
            _input.held_source_inv   = _inv;
            _input.held_source_index = _hover_slot;
            inventory_clear_slot(_inv, _hover_slot);
            _input.last_action  = "pickup";
            _input.action_timer = 10;
        }
    }
}

// ─────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────

/// Swaps the held item with a slot's contents.
function _inv_input_swap_with_held(_input, _inv, _index) {
    var _slot = _inv.slots[_index];
    var _tmp_id  = _slot.item_id;
    var _tmp_qty = _slot.qty;

    inventory_set_slot(_inv, _index, _input.held.item_id, _input.held.qty);
    _input.held.item_id = _tmp_id;
    _input.held.qty     = _tmp_qty;

    _input.held_source_inv   = _inv;
    _input.held_source_index = _index;

    _input.last_action  = "swap";
    _input.action_timer = 10;
}

/// Returns the held item to its source slot (cancel drag).
/// If the source slot is now occupied, tries to add to inventory.
function _inv_input_return_held(_input) {
    if (slot_is_empty(_input.held)) return;

    if (_input.held_source_inv != undefined && _input.held_source_index >= 0) {
        var _src_inv = _input.held_source_inv;
        var _src_idx = _input.held_source_index;
        var _src_slot = _src_inv.slots[_src_idx];

        if (slot_is_empty(_src_slot)) {
            // Source is still empty — return it
            inventory_set_slot(_src_inv, _src_idx, _input.held.item_id, _input.held.qty);
        } else {
            // Source is now occupied — try adding to that inventory
            var _leftover = inventory_add_item(_src_inv, _input.held.item_id, _input.held.qty);
            if (_leftover > 0) {
                // Inventory full — item is lost (or you could spawn a world entity)
                show_debug_message("WARNING: Lost " + string(_leftover) + "x " + _input.held.item_id + " (inventory full on cancel)");
            }
        }
    }

    _input.held = slot_create_empty();
    _input.held_source_inv   = undefined;
    _input.held_source_index = -1;
}

/// Checks if the input handler currently has an item held.
/// @param {struct} _input
/// @returns {bool}
function inv_input_is_holding(_input) {
    return !slot_is_empty(_input.held);
}
