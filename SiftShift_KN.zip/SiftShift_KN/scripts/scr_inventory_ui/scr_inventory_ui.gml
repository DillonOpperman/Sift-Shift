/// Returns a default UI config struct with warm parchment theme.
/// @returns {struct}
function inv_ui_config_create() {
    return {
        // Slot geometry
        slot_size:      52,     // pixels per slot (square)
        slot_padding:   2,      // thin grid lines between slots
        panel_padding:  6,      // padding inside the panel border
        icon_scale:     1.5,    // scale factor for item sprites

        // Colors — warm parchment / medieval palette
        col_panel_bg:        make_color_rgb(200, 168,  78),  // #c8a84e golden parchment
        col_panel_bg_dark:   make_color_rgb(160, 128,  48),  // #a08030 darker accent
        col_panel_border:    make_color_rgb(107,  90,  46),  // #6b5a2e dark brown frame
        col_panel_border_lt: make_color_rgb(218, 194, 120),  // #dac278 light inner edge

        col_slot_bg:         make_color_rgb(184, 152,  64),  // #b89840 warm tan
        col_slot_bg_light:   make_color_rgb(198, 170,  90),  // #c6aa5a lighter slot variant
        col_slot_border:     make_color_rgb(139, 115,  50),  // #8b7332 muted brown grid lines
        col_slot_hover:      make_color_rgb(255, 224, 128),  // #ffe080 bright gold highlight
        col_slot_selected:   make_color_rgb(255, 200,  80),  // #ffc850 selected gold
        col_slot_invalid:    make_color_rgb(200,  60,  60),  // #c83c3c muted red

        col_tab_bg:          make_color_rgb(160, 128,  48),  // #a08030 tab background
        col_tab_border:      make_color_rgb(107,  90,  46),  // #6b5a2e tab border
        col_tab_text:        make_color_rgb( 26,  26,  26),  // #1a1a1a near-black
        col_slot_number:     make_color_rgb( 92,  74,  32),  // #5c4a20 dark brown

        col_text:            make_color_rgb( 40,  32,  16),  // #281e10 dark brown text
        col_qty:             make_color_rgb( 26,  26,  26),  // #1a1a1a dark qty number
        col_qty_shadow:      make_color_rgb(200, 168,  78),  // #c8a84e subtle light shadow

        // Tooltip — darker parchment scroll style
        col_tooltip_bg:      make_color_rgb( 62,  50,  28),  // #3e321c dark brown
        col_tooltip_border:  make_color_rgb(107,  90,  46),  // #6b5a2e brown border
        col_tooltip_text:    make_color_rgb(230, 218, 180),  // #e6dab4 cream text
        col_tooltip_name:    make_color_rgb(255, 224, 128),  // #ffe080 gold name

        // Tooltip settings
        tooltip_width:  220,
        tooltip_alpha:  0.96,

        // Animation
        hover_pulse_speed: 0.04,
        drag_ghost_alpha:  0.65,

        // Tab settings
        tab_height:    30,      // height of the "Inventory" tab
        tab_width:     120,     // width of the tab

        // Show slot numbers on the first row (like the reference)
        show_slot_numbers: true,

        // Border thickness (drawn via multiple rects)
        border_width:  3,

        // Font (set to your font asset or -1 for default)
        font_normal: -1,
        font_small:  -1
    };
}

// ─────────────────────────────────────────────────────────────
// UI PANEL — one per visible inventory
// ─────────────────────────────────────────────────────────────

/// Creates a UI panel bound to an inventory.
/// @param {struct} _inv       The inventory data struct
/// @param {real}   _x         Screen X position (top-left of panel)
/// @param {real}   _y         Screen Y position
/// @param {string} _title     Display title ("Inventory", "Chest", etc.)
/// @param {struct} _config    Optional config override (or undefined)
/// @returns {struct}
function inv_ui_panel_create(_inv, _x, _y, _title, _config) {
    var _cfg = _config ?? inv_ui_config_create();

    var _panel = {
        inv:        _inv,
        x:          _x,
        y:          _y,
        title:      _title,
        config:     _cfg,
        visible:    true,
        draggable:  true,

        // Cached dimensions (computed once)
        grid_x:     0,
        grid_y:     0,
        width:      0,
        height:     0,
        tab_h:      0,

        // State
        hover_slot:     -1,
        hover_timer:    0,
        pulse_phase:    0
    };

    _inv_ui_calc_layout(_panel);
    return _panel;
}

/// Recalculates panel dimensions from inventory size + config.
function _inv_ui_calc_layout(_panel) {
    var _cfg  = _panel.config;
    var _inv  = _panel.inv;
    var _cell = _cfg.slot_size + _cfg.slot_padding;

    _panel.tab_h   = _cfg.tab_height;
    _panel.grid_x  = _panel.x + _cfg.panel_padding + _cfg.border_width;
    _panel.grid_y  = _panel.y + _panel.tab_h + _cfg.panel_padding + _cfg.border_width;
    _panel.width   = (_cell * _inv.cols) - _cfg.slot_padding + (_cfg.panel_padding * 2) + (_cfg.border_width * 2);
    _panel.height  = (_cell * _inv.rows) - _cfg.slot_padding + (_cfg.panel_padding * 2) + (_cfg.border_width * 2) + _panel.tab_h;
}

// ─────────────────────────────────────────────────────────────
// HIT TESTING
// ─────────────────────────────────────────────────────────────

/// Returns the slot index under the given screen coordinates,
/// or -1 if not over any slot.
function inv_ui_get_slot_at(_panel, _mx, _my) {
    var _cfg  = _panel.config;
    var _inv  = _panel.inv;
    var _cell = _cfg.slot_size + _cfg.slot_padding;

    var _lx = _mx - _panel.grid_x;
    var _ly = _my - _panel.grid_y;

    if (_lx < 0 || _ly < 0) return -1;

    var _col = floor(_lx / _cell);
    var _row = floor(_ly / _cell);

    var _in_slot_x = _lx - (_col * _cell);
    var _in_slot_y = _ly - (_row * _cell);
    if (_in_slot_x > _cfg.slot_size || _in_slot_y > _cfg.slot_size) return -1;

    if (_col < 0 || _col >= _inv.cols || _row < 0 || _row >= _inv.rows) return -1;

    return _row * _inv.cols + _col;
}

/// Returns true if the mouse is anywhere inside the panel rect.
function inv_ui_point_in_panel(_panel, _mx, _my) {
    return (
        _mx >= _panel.x &&
        _mx <= _panel.x + _panel.width &&
        _my >= _panel.y &&
        _my <= _panel.y + _panel.height
    );
}

// ─────────────────────────────────────────────────────────────
// DRAWING — Warm parchment style
// ─────────────────────────────────────────────────────────────

/// Master draw function for a panel. Call this each frame.
/// @param {struct} _panel
/// @param {real}   _mx        GUI mouse x
/// @param {real}   _my        GUI mouse y
/// @param {struct} _held_item Slot struct of currently held/dragged item (or undefined)
function inv_ui_draw(_panel, _mx, _my, _held_item) {
    if (!_panel.visible) return;

    var _cfg = _panel.config;
    var _inv = _panel.inv;

    _inv_ui_calc_layout(_panel);

    // Update hover state
    _panel.hover_slot = inv_ui_get_slot_at(_panel, _mx, _my);
    _panel.pulse_phase += _cfg.hover_pulse_speed;

    // ── Tab header ─────────────────────────────────────────
    // Draw the "Inventory" tab above the panel, like a folder tab
    var _tab_x = _panel.x + _cfg.border_width;
    var _tab_y = _panel.y;
    var _tab_w = _cfg.tab_width;
    var _tab_h = _cfg.tab_height;

    // Tab outer border
    draw_set_color(_cfg.col_panel_border);
    draw_rectangle(_tab_x - 1, _tab_y - 1, _tab_x + _tab_w + 1, _tab_y + _tab_h, false);

    // Tab fill
    draw_set_color(_cfg.col_tab_bg);
    draw_rectangle(_tab_x, _tab_y, _tab_x + _tab_w, _tab_y + _tab_h, false);

    // Light edge on top of tab
    draw_set_color(_cfg.col_panel_border_lt);
    draw_rectangle(_tab_x + 1, _tab_y + 1, _tab_x + _tab_w - 1, _tab_y + 2, false);

    // Tab text
    if (_cfg.font_normal != -1) draw_set_font(_cfg.font_normal);
    draw_set_halign(fa_center);
    draw_set_valign(fa_middle);
    draw_set_color(_cfg.col_tab_text);
    draw_text(_tab_x + _tab_w / 2, _tab_y + _tab_h / 2, _panel.title);

    // ── Panel body ─────────────────────────────────────────
    var _body_y = _panel.y + _tab_h;
    var _body_h = _panel.height - _tab_h;

    // Outer border (dark brown frame)
    draw_set_color(_cfg.col_panel_border);
    draw_rectangle(
        _panel.x, _body_y,
        _panel.x + _panel.width, _panel.y + _panel.height,
        false
    );

    // Inner border highlight (light edge for depth)
    draw_set_color(_cfg.col_panel_border_lt);
    draw_rectangle(
        _panel.x + _cfg.border_width - 1, _body_y + _cfg.border_width - 1,
        _panel.x + _panel.width - _cfg.border_width + 1, _panel.y + _panel.height - _cfg.border_width + 1,
        false
    );

    // Main panel background (golden parchment)
    draw_set_color(_cfg.col_panel_bg);
    draw_rectangle(
        _panel.x + _cfg.border_width, _body_y + _cfg.border_width,
        _panel.x + _panel.width - _cfg.border_width, _panel.y + _panel.height - _cfg.border_width,
        false
    );

    // ── Slot grid ──────────────────────────────────────────
    var _cell = _cfg.slot_size + _cfg.slot_padding;

    for (var i = 0; i < _inv.size; i++) {
        var _col = i mod _inv.cols;
        var _row = i div _inv.cols;
        var _sx  = _panel.grid_x + (_col * _cell);
        var _sy  = _panel.grid_y + (_row * _cell);
        var _slot = _inv.slots[i];

        // Slot background — alternating subtle shade for visual texture
        var _is_even = ((_col + _row) mod 2 == 0);
        var _slot_col = _is_even ? _cfg.col_slot_bg : _cfg.col_slot_bg_light;

        // Hover highlight
        if (i == _panel.hover_slot) {
            var _pulse = 0.5 + 0.5 * sin(_panel.pulse_phase * pi * 2);
            _slot_col = merge_color(_slot_col, _cfg.col_slot_hover, 0.3 + 0.2 * _pulse);

            // Invalid drop coloring
            if (_held_item != undefined && !slot_is_empty(_held_item)) {
                if (!slot_is_empty(_slot)
                    && _slot.item_id != _held_item.item_id
                    && _slot.qty >= item_db_max_stack(_slot.item_id)) {
                    _slot_col = merge_color(_slot_col, _cfg.col_slot_invalid, 0.4);
                }
            }
        }

        // Draw slot fill
        draw_set_color(_slot_col);
        draw_rectangle(_sx, _sy, _sx + _cfg.slot_size - 1, _sy + _cfg.slot_size - 1, false);

        // Slot grid lines (thin brown borders forming the grid)
        draw_set_color(_cfg.col_slot_border);
        draw_rectangle(_sx, _sy, _sx + _cfg.slot_size - 1, _sy + _cfg.slot_size - 1, true);

        // ── Slot number (first row only) ───────────────────
        if (_cfg.show_slot_numbers && _row == 0) {
            if (_cfg.font_small != -1) draw_set_font(_cfg.font_small);
            draw_set_halign(fa_left);
            draw_set_valign(fa_top);
            draw_set_color(_cfg.col_slot_number);
            draw_text(_sx + 3, _sy + 1, string(_col + 1));
        }

        // ── Item icon + quantity ───────────────────────────
        if (!slot_is_empty(_slot)) {
            var _def = item_db_get(_slot.item_id);
            if (_def != undefined) {
                // Center the sprite in the slot
                // Offset by sprite origin so it's always visually centered,
                // regardless of whether the sprite origin is top-left or middle
                var _sw = sprite_get_width(_def.sprite) * _cfg.icon_scale;
                var _sh = sprite_get_height(_def.sprite) * _cfg.icon_scale;
                var _ox = sprite_get_xoffset(_def.sprite) * _cfg.icon_scale;
                var _oy = sprite_get_yoffset(_def.sprite) * _cfg.icon_scale;
                var _icon_x = _sx + (_cfg.slot_size - _sw) / 2 + _ox;
                var _icon_y = _sy + (_cfg.slot_size - _sh) / 2 + _oy;
                draw_sprite_ext(
                    _def.sprite, _def.image_index,
                    _icon_x, _icon_y,
                    _cfg.icon_scale, _cfg.icon_scale,
                    0, c_white, 1
                );

                // Quantity overlay (bottom-right, dark text on light bg)
                if (_slot.qty > 1) {
                    var _qty_str = string(_slot.qty);
                    var _tx = _sx + _cfg.slot_size - 3;
                    var _ty = _sy + _cfg.slot_size - 3;

                    if (_cfg.font_small != -1) draw_set_font(_cfg.font_small);
                    draw_set_halign(fa_right);
                    draw_set_valign(fa_bottom);

                    // Light outline/shadow for readability
                    draw_set_color(_cfg.col_qty_shadow);
                    draw_text(_tx + 1, _ty + 1, _qty_str);
                    draw_text(_tx - 1, _ty - 1, _qty_str);

                    // Dark quantity text
                    draw_set_color(_cfg.col_qty);
                    draw_text(_tx, _ty, _qty_str);
                }
            }
        }
    }

    // Reset draw state
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
    draw_set_color(c_white);
    draw_set_alpha(1);
}

// ─────────────────────────────────────────────────────────────
// TOOLTIP — parchment scroll style
// ─────────────────────────────────────────────────────────────

/// Draws a tooltip for the hovered slot. Call AFTER inv_ui_draw.
function inv_ui_draw_tooltip(_panel, _mx, _my) {
    if (!_panel.visible) return;
    if (_panel.hover_slot < 0) return;

    var _slot = _panel.inv.slots[_panel.hover_slot];
    if (slot_is_empty(_slot)) return;

    var _def = item_db_get(_slot.item_id);
    if (_def == undefined) return;

    var _cfg = _panel.config;
    var _w   = _cfg.tooltip_width;

    // Build text lines
    var _name  = _def.name;
    var _desc  = variable_struct_exists(_def, "description") ? _def.description : "";
    var _cat   = variable_struct_exists(_def, "category")
        ? string_upper(string_char_at(_def.category, 1))
          + string_copy(_def.category, 2, string_length(_def.category) - 1)
        : "";
    var _qty_line = "Quantity: " + string(_slot.qty) + " / " + string(_def.max_stack);

    // Calculate height
    if (_cfg.font_normal != -1) draw_set_font(_cfg.font_normal);
    var _line_h = string_height("A") + 2;
    var _h = 10;
    _h += _line_h;      // name
    _h += _line_h;      // category
    _h += _line_h;      // quantity
    if (_desc != "") {
        var _wrapped = _inv_ui_wrap_text(_desc, _w - 20);
        _h += _line_h * array_length(_wrapped);
    }
    _h += 10;

    // Position tooltip (keep on screen)
    var _tx = _mx + 16;
    var _ty = _my + 16;
    if (_tx + _w > display_get_gui_width())  _tx = _mx - _w - 8;
    if (_ty + _h > display_get_gui_height()) _ty = _my - _h - 8;

    // Draw dark parchment background
    draw_set_alpha(_cfg.tooltip_alpha);

    // Border
    draw_set_color(_cfg.col_tooltip_border);
    draw_rectangle(_tx - 2, _ty - 2, _tx + _w + 2, _ty + _h + 2, false);

    // Fill
    draw_set_color(_cfg.col_tooltip_bg);
    draw_rectangle(_tx, _ty, _tx + _w, _ty + _h, false);
    draw_set_alpha(1);

    // Draw text
    var _cy = _ty + 8;
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);

    // Item name (gold highlight)
    draw_set_color(_cfg.col_tooltip_name);
    draw_text(_tx + 10, _cy, _name);
    _cy += _line_h;

    // Category
    draw_set_color(_cfg.col_tooltip_text);
    draw_text(_tx + 10, _cy, _cat);
    _cy += _line_h;

    // Quantity line
    draw_text(_tx + 10, _cy, _qty_line);
    _cy += _line_h;

    // Description (word-wrapped)
    if (_desc != "") {
        var _lines = _inv_ui_wrap_text(_desc, _w - 20);
        for (var i = 0; i < array_length(_lines); i++) {
            draw_text(_tx + 10, _cy, _lines[i]);
            _cy += _line_h;
        }
    }

    // Reset
    draw_set_color(c_white);
    draw_set_halign(fa_left);
    draw_set_valign(fa_top);
}

// ─────────────────────────────────────────────────────────────
// DRAG GHOST
// ─────────────────────────────────────────────────────────────

/// Draws the currently held/dragged item at the cursor position.
function inv_ui_draw_held_item(_held, _mx, _my, _config) {
    if (_held == undefined || slot_is_empty(_held)) return;

    var _def = item_db_get(_held.item_id);
    if (_def == undefined) return;

    var _cfg = _config ?? inv_ui_config_create();

    // Draw sprite centered on cursor
    draw_set_alpha(_cfg.drag_ghost_alpha);
    draw_sprite_ext(
        _def.sprite, _def.image_index,
        _mx, _my,
        _cfg.icon_scale, _cfg.icon_scale,
        0, c_white, _cfg.drag_ghost_alpha
    );
    draw_set_alpha(1);

    // Draw quantity
    if (_held.qty > 1) {
        if (_cfg.font_small != -1) draw_set_font(_cfg.font_small);
        draw_set_halign(fa_right);
        draw_set_valign(fa_bottom);
        draw_set_color(_cfg.col_qty_shadow);
        draw_text(_mx + _cfg.slot_size / 2 + 1, _my + _cfg.slot_size / 2 + 1, string(_held.qty));
        draw_set_color(_cfg.col_qty);
        draw_text(_mx + _cfg.slot_size / 2, _my + _cfg.slot_size / 2, string(_held.qty));
        draw_set_halign(fa_left);
        draw_set_valign(fa_top);
        draw_set_color(c_white);
    }
}

// ─────────────────────────────────────────────────────────────
// TEXT UTILITIES
// ─────────────────────────────────────────────────────────────

/// Simple word-wrap: returns an array of strings fitting _max_width.
function _inv_ui_wrap_text(_text, _max_width) {
    var _words = [];
    var _lines = [];
    var _current = "";

    var _remaining = _text;
    while (string_length(_remaining) > 0) {
        var _space = string_pos(" ", _remaining);
        if (_space == 0) {
            array_push(_words, _remaining);
            _remaining = "";
        } else {
            array_push(_words, string_copy(_remaining, 1, _space - 1));
            _remaining = string_delete(_remaining, 1, _space);
        }
    }

    for (var i = 0; i < array_length(_words); i++) {
        var _test = (_current == "") ? _words[i] : _current + " " + _words[i];
        if (string_width(_test) > _max_width && _current != "") {
            array_push(_lines, _current);
            _current = _words[i];
        } else {
            _current = _test;
        }
    }
    if (_current != "") array_push(_lines, _current);

    return _lines;
}
