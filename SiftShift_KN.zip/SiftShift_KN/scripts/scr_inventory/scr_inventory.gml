/// Creates a new inventory with the given number of slots.
/// @param {real}     _cols       Number of columns (for UI hint)
/// @param {real}     _rows       Number of rows
/// @param {string}   _owner_tag  A label like "player", "chest_01"
/// @returns {struct} The inventory struct
function inventory_create(_cols, _rows, _owner_tag) {
    var _inv = {
        cols:       _cols,
        rows:       _rows,
        size:       _cols * _rows,
        owner_tag:  _owner_tag,
        slots:      [],
        on_change:  undefined   // callback(inv, slot_index)
    };

    // Initialize all slots as empty
    for (var i = 0; i < _inv.size; i++) {
        array_push(_inv.slots, slot_create_empty());
    }

    return _inv;
}

/// Creates an empty slot struct.
/// @returns {struct}
function slot_create_empty() {
    return {
        item_id: "",
        qty:     0
    };
}

/// Returns true if a slot is empty.
/// @param {struct} _slot
/// @returns {bool}
function slot_is_empty(_slot) {
    return (_slot.item_id == "" || _slot.qty <= 0);
}

// ─────────────────────────────────────────────────────────────
// CORE OPERATIONS
// ─────────────────────────────────────────────────────────────

/// Sets a slot directly (used internally and for drag-drop).
/// Fires on_change.
/// @param {struct} _inv
/// @param {real}   _index
/// @param {string} _item_id
/// @param {real}   _qty
function inventory_set_slot(_inv, _index, _item_id, _qty) {
    if (_index < 0 || _index >= _inv.size) return;

    var _slot = _inv.slots[_index];
    if (_qty <= 0) {
        _slot.item_id = "";
        _slot.qty     = 0;
    } else {
        _slot.item_id = _item_id;
        _slot.qty     = _qty;
    }

    _inventory_notify(_inv, _index);
}

/// Clears a single slot.
/// @param {struct} _inv
/// @param {real}   _index
function inventory_clear_slot(_inv, _index) {
    inventory_set_slot(_inv, _index, "", 0);
}

/// Fires the on_change callback if one is set.
function _inventory_notify(_inv, _index) {
    if (_inv.on_change != undefined) {
        _inv.on_change(_inv, _index);
    }
}

// ─────────────────────────────────────────────────────────────
// ADD / REMOVE ITEMS
// ─────────────────────────────────────────────────────────────

/// Adds items to the inventory. Stacks onto existing matching
/// slots first, then fills empty slots. Returns the leftover
/// quantity that didn't fit (0 = everything was added).
///
/// @param {struct} _inv
/// @param {string} _item_id
/// @param {real}   _qty
/// @returns {real}  Leftover quantity
function inventory_add_item(_inv, _item_id, _qty) {
    var _max = item_db_max_stack(_item_id);
    var _remaining = _qty;

    // Pass 1: Stack onto existing slots with the same item
    for (var i = 0; i < _inv.size && _remaining > 0; i++) {
        var _slot = _inv.slots[i];
        if (_slot.item_id == _item_id && _slot.qty < _max) {
            var _space = _max - _slot.qty;
            var _add   = min(_space, _remaining);
            _slot.qty   += _add;
            _remaining  -= _add;
            _inventory_notify(_inv, i);
        }
    }

    // Pass 2: Fill empty slots
    for (var i = 0; i < _inv.size && _remaining > 0; i++) {
        if (slot_is_empty(_inv.slots[i])) {
            var _add = min(_max, _remaining);
            _inv.slots[i].item_id = _item_id;
            _inv.slots[i].qty     = _add;
            _remaining -= _add;
            _inventory_notify(_inv, i);
        }
    }

    return _remaining;
}

/// Removes a quantity of an item from the inventory.
/// Pulls from slots in order. Returns the amount actually removed.
///
/// @param {struct} _inv
/// @param {string} _item_id
/// @param {real}   _qty
/// @returns {real}  Amount actually removed
function inventory_remove_item(_inv, _item_id, _qty) {
    var _to_remove = _qty;

    for (var i = 0; i < _inv.size && _to_remove > 0; i++) {
        var _slot = _inv.slots[i];
        if (_slot.item_id == _item_id) {
            var _take = min(_slot.qty, _to_remove);
            _slot.qty  -= _take;
            _to_remove -= _take;

            if (_slot.qty <= 0) {
                _slot.item_id = "";
                _slot.qty     = 0;
            }
            _inventory_notify(_inv, i);
        }
    }

    return _qty - _to_remove;
}

/// Counts total quantity of an item across all slots.
/// @param {struct} _inv
/// @param {string} _item_id
/// @returns {real}
function inventory_count_item(_inv, _item_id) {
    var _total = 0;
    for (var i = 0; i < _inv.size; i++) {
        if (_inv.slots[i].item_id == _item_id) {
            _total += _inv.slots[i].qty;
        }
    }
    return _total;
}

/// Returns true if inventory has at least _qty of _item_id.
/// @param {struct} _inv
/// @param {string} _item_id
/// @param {real}   _qty
/// @returns {bool}
function inventory_has_item(_inv, _item_id, _qty) {
    return inventory_count_item(_inv, _item_id) >= _qty;
}

// ─────────────────────────────────────────────────────────────
// SLOT-TO-SLOT OPERATIONS (for drag-drop)
// ─────────────────────────────────────────────────────────────

/// Swaps the contents of two slots. Works across inventories.
/// @param {struct} _inv_a
/// @param {real}   _idx_a
/// @param {struct} _inv_b
/// @param {real}   _idx_b
function inventory_swap_slots(_inv_a, _idx_a, _inv_b, _idx_b) {
    var _a = _inv_a.slots[_idx_a];
    var _b = _inv_b.slots[_idx_b];

    var _tmp_id  = _a.item_id;
    var _tmp_qty = _a.qty;

    _a.item_id = _b.item_id;
    _a.qty     = _b.qty;
    _b.item_id = _tmp_id;
    _b.qty     = _tmp_qty;

    _inventory_notify(_inv_a, _idx_a);
    _inventory_notify(_inv_b, _idx_b);
}

/// Attempts to merge source slot into destination slot.
/// If they're the same item, stacks as much as possible.
/// If different items, swaps them.
/// Returns true if a merge happened, false if swapped.
///
/// @param {struct} _inv_src
/// @param {real}   _idx_src
/// @param {struct} _inv_dst
/// @param {real}   _idx_dst
/// @returns {bool} true = merged, false = swapped
function inventory_merge_or_swap(_inv_src, _idx_src, _inv_dst, _idx_dst) {
    var _src = _inv_src.slots[_idx_src];
    var _dst = _inv_dst.slots[_idx_dst];

    // If destination is empty, just move
    if (slot_is_empty(_dst)) {
        _dst.item_id = _src.item_id;
        _dst.qty     = _src.qty;
        _src.item_id = "";
        _src.qty     = 0;
        _inventory_notify(_inv_src, _idx_src);
        _inventory_notify(_inv_dst, _idx_dst);
        return true;
    }

    // Same item: try to merge/stack
    if (_src.item_id == _dst.item_id) {
        var _max   = item_db_max_stack(_dst.item_id);
        var _space = _max - _dst.qty;
        var _move  = min(_space, _src.qty);

        if (_move > 0) {
            _dst.qty += _move;
            _src.qty -= _move;
            if (_src.qty <= 0) {
                _src.item_id = "";
                _src.qty     = 0;
            }
            _inventory_notify(_inv_src, _idx_src);
            _inventory_notify(_inv_dst, _idx_dst);
            return true;
        }
    }

    // Different items or destination full: swap
    inventory_swap_slots(_inv_src, _idx_src, _inv_dst, _idx_dst);
    return false;
}

/// Splits a stack: takes half (rounded down) from source and
/// places it in a new "held" struct. Used for right-click split.
///
/// @param {struct} _inv
/// @param {real}   _index
/// @returns {struct} A slot struct with the split portion, or empty
function inventory_split_stack(_inv, _index) {
    var _slot = _inv.slots[_index];
    if (slot_is_empty(_slot) || _slot.qty <= 1) {
        return slot_create_empty();
    }

    var _half = _slot.qty div 2;
    var _split = {
        item_id: _slot.item_id,
        qty:     _half
    };
    _slot.qty -= _half;

    _inventory_notify(_inv, _index);
    return _split;
}

// ─────────────────────────────────────────────────────────────
// EXPANSION / RESIZE
// ─────────────────────────────────────────────────────────────

/// Adds more rows to an inventory (e.g., player upgrades storage).
/// @param {struct} _inv
/// @param {real}   _extra_rows
function inventory_expand(_inv, _extra_rows) {
    var _extra = _inv.cols * _extra_rows;
    for (var i = 0; i < _extra; i++) {
        array_push(_inv.slots, slot_create_empty());
    }
    _inv.rows += _extra_rows;
    _inv.size  = _inv.cols * _inv.rows;
}

// ─────────────────────────────────────────────────────────────
// SERIALIZATION (for save/load)
// ─────────────────────────────────────────────────────────────

/// Converts inventory to a JSON-compatible struct for saving.
/// @param {struct} _inv
/// @returns {struct}
function inventory_serialize(_inv) {
    var _data = {
        cols:      _inv.cols,
        rows:      _inv.rows,
        owner_tag: _inv.owner_tag,
        slots:     []
    };
    for (var i = 0; i < _inv.size; i++) {
        array_push(_data.slots, {
            item_id: _inv.slots[i].item_id,
            qty:     _inv.slots[i].qty
        });
    }
    return _data;
}

/// Restores inventory from a saved struct.
/// @param {struct} _data   The struct from inventory_serialize
/// @returns {struct}       A fully reconstituted inventory
function inventory_deserialize(_data) {
    var _inv = inventory_create(_data.cols, _data.rows, _data.owner_tag);
    var _count = min(array_length(_data.slots), _inv.size);
    for (var i = 0; i < _count; i++) {
        _inv.slots[i].item_id = _data.slots[i].item_id;
        _inv.slots[i].qty     = _data.slots[i].qty;
    }
    return _inv;
}
