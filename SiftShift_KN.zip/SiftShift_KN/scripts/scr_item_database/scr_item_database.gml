/// Initializes the global item database. Call once in a persistent
/// controller object's Create event.
function item_db_init() {
    global.item_database = {};

    // ── Raw Resources ──────────────────────────────────────
    item_db_register("copper_ore", {
        name:        "Copper Ore",
        sprite:      Spr_CopperOre,
        image_index: 0,
        max_stack:   64,
        category:    "raw",
        description: "Raw copper. Conducts electricity well.",
        value:       2
    });
}

/// Registers a single item definition into the database.
/// @param {string} _item_id   Unique key (e.g., "iron_ore")
/// @param {struct} _data      Struct with item metadata
function item_db_register(_item_id, _data) {
    // Inject the id into the struct for self-reference
    _data[$ "item_id"] = _item_id;

    // Default max_stack if not provided
    if (!variable_struct_exists(_data, "max_stack")) {
        _data[$ "max_stack"] = 64;
    }

    global.item_database[$ _item_id] = _data;
}

/// Returns the definition struct for an item, or undefined.
/// @param {string} _item_id
/// @returns {struct|undefined}
function item_db_get(_item_id) {
    if (variable_struct_exists(global.item_database, _item_id)) {
        return global.item_database[$ _item_id];
    }
    return undefined;
}

/// Returns the max stack size for an item.
/// @param {string} _item_id
/// @returns {real}
function item_db_max_stack(_item_id) {
    var _def = item_db_get(_item_id);
    if (_def != undefined) {
        return _def[$ "max_stack"];
    }
    return 1;
}

/// Returns an array of all registered item IDs.
/// @returns {array<string>}
function item_db_get_all_ids() {
    return variable_struct_get_names(global.item_database);
}
 