// gets x and y and snaps it to the 32x32 grid
var mx = mouse_x div tile_size;
var my = mouse_y div tile_size;
 
hover_x = mx * tile_size;
hover_y = my * tile_size;

hovered_facility = instance_position(mouse_x, mouse_y, all);
 
// INPUT GUARD: skip click processing after load/resume
if (variable_global_exists("_input_guard") && global._input_guard > 0) {
    exit;
}
 
// INVENTORY OPEN: skip clicks while inventory panel is up
if (variable_global_exists("_mouse_over_inv") && global._mouse_over_inv) {
    exit;
}
 
// when mouse is clicked on question tiles it removes them
if (mouse_check_button_pressed(mb_left)) {
    // gets the id of buyable layer
    var layer_id = layer_get_id("Tiles_Buyable");
    // gets the tile map ID of that layer
    var map_id = layer_tilemap_get_id(layer_id);
 
    // finds top left of box mouse is in
    var big_x = (mouse_x div 32) * 32;
    var big_y = (mouse_y div 32) * 32;
 
    // gets tile at mouse position
    var clicked_tile = tilemap_get_at_pixel(map_id, big_x, big_y);
 
    // removes 2x2 tile if not empty, -1 is to keep within total 2x2 box
    if (clicked_tile == 0) {
        if (global.gold >= 1) {
           
            switch (facility) {
                case 1: 
					if (global.gold >= 1 && hovered_facility == noone) {
						global.gold -= 1;
						instance_create_layer(big_x, big_y, layer_get_id("In_Factory"), Obj_Belt);
					}
				break;
                case 2: 
					if (global.gold >= 16 && hovered_facility == noone) {
						global.gold -= 16;
						instance_create_layer(big_x, big_y, layer_get_id("In_Factory"), Obj_Mine); 
					}
				break;
                case 3: 
					if (global.gold >= 32 && hovered_facility == noone) {
						global.gold -= 32;
						instance_create_layer(big_x, big_y, layer_get_id("In_Factory"), Obj_Smelter);
					} 
				break;
                case 4: 
					if (global.gold >= 32 && hovered_facility == noone) {
						global.gold -= 32;
						instance_create_layer(big_x, big_y, layer_get_id("In_Factory"), Obj_Blacksmith); 
					}
				break;
                case 5: 
					if (global.gold >= 32 && hovered_facility == noone) {
						global.gold -= 32;
						instance_create_layer(big_x, big_y, layer_get_id("In_Factory"), Obj_Sawmill); 
					}
				break;
                case 6: 
					if (global.gold >= 16 && hovered_facility == noone) {
						global.gold -= 16;
						instance_create_layer(big_x, big_y, layer_get_id("In_Factory"), Obj_Timbermill); 
					}
				break;
                case 7: 
					if (global.gold >= 32 && hovered_facility == noone) {
						global.gold -= 32;
						instance_create_layer(big_x, big_y, layer_get_id("In_Factory"), Obj_Warehouse); 
					}
				break;
				case 8: 
				if(hovered_facility != noone){
					var refund = 0;
					switch(hovered_facility.object_index){
						case Obj_Belt: refund = 1; break;
						case Obj_Mine: refund = 16; break;
						case Obj_Smelter: refund = 32; break;
						case Obj_Blacksmith: refund = 32; break;
						case Obj_Sawmill: refund = 32; break;
						case Obj_Timbermill: refund = 16; break;
						case Obj_Warehouse: refund = 32; break;
					}
					global.gold += refund;
					instance_destroy(hovered_facility); 
				}
				break;
			}
        }
    }
}